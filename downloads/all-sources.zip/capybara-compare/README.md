同一提示词、五个模型的水豚发条飞艇源码。

- claude.zip — AWS Quick Smart
- gemini-neon.zip — Gemini 4 Neon
- muse.zip — Muse
- deepseek.zip — DeepSeek V4.1 Flash 1017
- gpt-sol.zip — GPT 6.1 Sol
