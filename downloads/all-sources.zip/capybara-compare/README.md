同一提示词、四个模型的水豚发条飞艇源码。

- claude.zip — Claude
- gemini-neon.zip — Gemini 4 Neon
- muse.zip — Muse
- deepseek.zip — DeepSeek V4.1 Flash 1017
