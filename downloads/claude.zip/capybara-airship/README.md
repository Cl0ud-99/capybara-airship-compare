# 发条水豚飞艇 / The Clockwork Capybara

单文件 Three.js 场景：戴飞行护目镜的水豚驾驶一艘发条木制飞艇，支持轨道控制。

## 运行
- 直接用现代浏览器（Chrome / Edge / Firefox）打开 `capybara-airship.html`。
- 首次打开需联网，从 jsDelivr CDN 加载 Three.js r160。
- 也可本地起服务：`python -m http.server 8765`，然后访问 http://localhost:8765/capybara-airship.html

## 操作
- 左键拖动：旋转视角；右键拖动：平移；滚轮：缩放
- 首次交互前镜头会自动缓慢环绕
